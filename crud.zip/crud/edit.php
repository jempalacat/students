<?php
include 'config.php';

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];

    $sql = "UPDATE students SET name = ?, email = ?, age = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$name, $email, $age, $id]);

    header("Location: index.php");
    exit;
}

$sql = "SELECT * FROM students WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id]);
$student = $stmt->fetch();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Edit Student</title>
</head>
<body>
    <h1>Edit Student</h1>
    <form method="POST">
        <label>Name</label>
        <input type="text" name="name" value="<?= $student['name']; ?>" required><br>
        <label>Email</label>
        <input type="email" name="email" value="<?= $student['email']; ?>" required><br>
        <label>Age</label>
        <input type="number" name="age" value="<?= $student['age']; ?>" required><br>
        <button type="submit">Update Student</button>
    </form>
</body>
</html>
